function mostrarVentanaEmergente(costoCOP, costoUSD) {
    alert(`¡Has seleccionado alquilar este almacén!\nCosto en COP: ${costoCOP}\nCosto en USD: ${costoUSD}`);
}