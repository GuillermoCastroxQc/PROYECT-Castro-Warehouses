// Función para calcular la suma total basada en los valores del formulario
function calcularSumaTotal() {
    // Obtener la duración del alquiler
    var duracionAlquiler = parseInt(document.getElementById("duracionAlquiler").value);

    // Obtener el tipo de almacén seleccionado
    var tipoAlmacen = document.getElementById("tipoAlmacen").value;

    // Obtener la ciudad seleccionada
    var ciudad = document.getElementById("ciudad").value;
    
    // Definir los precios base según el tipo de almacén
    var preciosBase = {
        pequeno: 600000, // Precio mensual para almacén pequeño
        mediano: 1200000, // Precio mensual para almacén mediano
        grande: 2400000 // Precio mensual para almacén grande
    };

    // Aplicar aumentos según la ubicación
    var aumentoPorUbicacion = {
        bogota: 0.1, // Aumento del 10% para Bogotá
        medellin: 0.1, // Aumento del 10% para Medellín
        cali: 0.05, // Aumento del 5% para Cali
        pereira: 0.05, // Aumento del 5% para Pereira
        "santa-marta": 0.1, // Aumento del 10% para Santa Marta
        ibague: 0.05 // Aumento del 5% para Ibagué
    };

    // Calcular el precio base
    var precioBase = preciosBase[tipoAlmacen];

    // Aplicar aumento por ubicación
    var aumento = precioBase * aumentoPorUbicacion[ciudad];

    // Calcular la suma total en COP
    var sumaTotalCOP = duracionAlquiler * (precioBase + aumento);

    // Calcular la suma total en USD (tasa de cambio: 1 USD = 2,700 COP)
    var tasaCambio = 2700;
    var sumaTotalUSD = sumaTotalCOP / tasaCambio;

    // Mostrar la suma total en COP
    document.getElementById("cantidadTotalCOP").value = sumaTotalCOP.toFixed(2) + " COP";

    // Mostrar la suma total en USD
    document.getElementById("cantidadTotalUSD").value = sumaTotalUSD.toFixed(2) + " USD";
}

// Asignar la función al evento de cambio en la duración del alquiler
document.getElementById("duracionAlquiler").addEventListener("change", function () {
    console.log("Evento de cambio ejecutado");
    calcularSumaTotal();
});

// Asignar la función al evento de cambio en cualquier elemento del formulario
var formElements = document.querySelectorAll("#tipoAlmacen, #ciudad, #duracionAlquiler");
formElements.forEach(function (element) {
    element.addEventListener("change", calcularSumaTotal);
});

// Ejecutar la función al cargar la página para mostrar el total inicial
calcularSumaTotal();